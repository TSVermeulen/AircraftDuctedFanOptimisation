# Ducted Fan Design Code (DFDC) validation of the UDC against the Bell X-22A ducted propeller wind tunnel data

DFDC is a specialized aerodynamic analysis and design software for ducted fan propulsors. It performs low-fidelity aerodynamic analysis of axisymmetric ducted fan systems. See more information [on the official website](https://web.mit.edu/drela/Public/web/dfdc).

This subfolder contains the DFDC case file definitions for the Bell X-22A at tip set angles of 14.5 and 24.5 degrees, together with the output data obtained from DFDC in `.csv` format. These files were used for further validation of the UDC.

The case files contain 4 different blocks specifying the configuration of operating conditions (OPER), airfoil properties (AERO), blade geometry (ROTOR) and duct and centerbody geometries (GEOM).

The output csv files contain:

- J: Advance ratio

- CT: Thrust Coefficient, nondimensionalised using the rotational rate of the blade, CT=T/(rho*n^2*d^4)

- CP: Power Coefficient, nondimensionalised using the rotational rate of the blade, CP=P/(rho*n^3*d^5)

```batch
└── X22A DFDC Data                               # DFDC solver results
    ├── README.md                                # This file
    ├── beta_145.case                            # input case file for 14.5 degrees blade angle 
    ├── beta_245.case                            # input case file for 24.5 degrees blade angle
    ├── dfdc_beta145.csv                         # DFDC results for 14.5 degrees 
    └── dfdc_beta245.csv                         # DFDC results for 24.5 degrees
```
