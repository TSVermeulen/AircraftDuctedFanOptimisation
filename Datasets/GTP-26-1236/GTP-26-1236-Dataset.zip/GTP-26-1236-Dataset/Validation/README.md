# Validation data of the UDC against the Bell X-22A

This folder contains all files and data used to perform the validation of the Unified Ducted fan Code (UDC) against Ducted Fan Design Code (DFDC) and experimental wind tunnel data of the X-22A ducted propeller.

Three spreadsheets are contained in this folder:

- `Validation Data.xlsx`: contains the NASA wind tunnel experimental data taken from NASA-TN-D-4142, for the X-22A at 14.5 and 24.5 degree blade tip angles. This corresponds to blade angles of 19 and 29 degrees at the 75% span station, which is the reference datum used in the experimental data. It also contains the output data obtained from the UDC for the same two blade tip angles considered. The comparison shows:
        - OMEGA: Nondimensionalised rotational rate used internally in the UDC/MTFLOW. Defined as RPS * 2 * PI * D / V
        - V: Freestream velocity in m/s
        - RPS: The rotational rate of the blade row in Hz
        - J: Advance ratio
        - CT: Thrust Coefficient, normalised using the rotational rate
        - CP: Power Coefficient, normalised using the rotational rate
        - EtaP: Propulsor Efficiency, CT/CP * J

- `Uncertainties on Experimental X22A Data.xlsx`: a Monte-Carlo sheet to estimate the 95% confidence intervals for the experimental data based on the reported uncertainties in NASA-TN-D-4142 and the uniform read-off error of halfwidth 0.01. Be aware that the file size will increase rapidly if the sample size is increased in its inputs. See also the intructions within the file.

- `X22A Propeller Design Data.xlsx`: The chord, geometric parameters, and collective blade angle distributions for the X-22A blade.

Additionally, there are 2 subfolders:

- `X22A Blade Profiles`: contains the blade profiles for the X-22A propeller used to evaluate the UDC. There are 9 profiles at different radii. These profiles are provided as input for MTFLOW analysis. The subfolder also contains the diagonal and horizontal strut airfoil profiles.

- `X22A DFDC Data`: contains the results comparing DFDC vs MTFLOW (see `./X22A DFDC Data/README.md` for further details).

```batch
.
└── Validation
    ├── README.md
    ├── Uncertainties on Experimental X22A Data.xlsx  # uncertainty analysis
    ├── Validation Data.xlsx                          # main validation results
    ├── X22A Blade Profiles                           # airfoil geometry
    │   ├── Dstrut.dat                                # diagonal strut profile
    │   ├── Hstrut.dat                                # horizontal strut profile
    │   ├── X22_02R.dat    
    │   ├── X22_03R.dat
    │   ├── X22_04R.dat
    │   ├── X22_05R.dat
    │   ├── X22_06R.dat
    │   ├── X22_07R.dat
    │   ├── X22_08R.dat
    │   ├── X22_09R.dat
    │   └── X22_10R.dat
    ├── X22A DFDC Data                               # DFDC solver results
    │   ├── README.md
    │   ├── beta_145.case                            # input case file for 14.5 degrees blade angle
    │   ├── beta_245.case                            # input case file for 24.5 degrees blade angle
    │   ├── dfdc_beta145.csv                         # DFDC results for 14.5 degrees
    │   └── dfdc_beta245.csv                         # DFDC results for 24.5 degrees
    └── X22A Propeller Design Data.xlsx               # X-22A design parameters
```
